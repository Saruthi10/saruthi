package Datatypes;

public class WithLAndWithoutL{
public static void main(String[] args) {
	long withL=12345678567843999l;
	long withoutL=12346639;
	System.out.println("With L:"+withL);
	System.out.println("Without L:"+withoutL);
}
}
