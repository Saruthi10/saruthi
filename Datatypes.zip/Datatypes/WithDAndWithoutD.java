package Datatypes;

public class WithDAndWithoutD {
public static void main(String[] args) {
	double withD=1.52222222d;
	double withoutD=5.222222222222222222222;
	System.out.println("With D:"+withD);
	System.out.println("Without D:"+withoutD);
}
}
