package Datatypes;
public class BasicDeclaration {
public static void main(String[] args) {
	int a=10;
	char c='s';
	float b=1;
	String s="Hello";
	long l=1234567;
	double d=123.45;
	System.out.println("Integer:"+a);
	System.out.println("Character:"+c);
	System.out.println("Float:"+b);
	System.out.println("String:"+s);
	System.out.println("Long:"+l);
	System.out.println("Double:"+d);
}
}
