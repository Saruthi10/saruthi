package ConditionalStatements;
import java.util.Scanner;
public class FindTheTriangle {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter three side length of triangle:");
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		if(a==b&&b==c) {
			System.out.println("Equilateral triangle");
		}
		else if(a==b||b==c||a==c) {
			System.out.println("Isosceles triangle");
		}else {
			System.out.println("Scalene triangle");
		}
		s.close();
	}
}
