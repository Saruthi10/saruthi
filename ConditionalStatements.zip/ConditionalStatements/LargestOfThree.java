package ConditionalStatements;
import java.util.Scanner;
public class LargestOfThree {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("A : ");
		int a=sc.nextInt();
		System.out.println("B : ");
		int b=sc.nextInt();
		System.out.println("C : ");
		int c=sc.nextInt();
		if((a>b)&&(a>c)) {
			System.out.println("A:"+a+" is Greater");
		}
		else if((b>a)&&(b>c)) {
			System.out.println("B:"+b+" is Greater");
		}
		else {
			System.out.println("C30:"+c+" is Greater");
		}
		sc.close();
	}
}
