package ConditionalStatements;
import java.util.Scanner;
public class DeterminationOfAngle {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the degree:");
		int deg=sc.nextInt();
		if(deg==90) {
			System.out.println("Right angle");
		}else if(deg==180) {
			System.out.println("Straigth angle");
		}else if(deg==360) {
			System.out.println("Complete Angle");
		}else if(deg<90 && deg>0) {
			System.out.println("Acute angle");
		}else if(deg>90 && deg<180) {
			System.out.println("Obsute angle");
		}
		else if(deg>180 && deg<360) {
			System.out.println("Reflex angle");
		}else {
			System.out.println("Invalid input");
		}
		sc.close();
	}
}
