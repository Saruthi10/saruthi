package ConditionalStatements;
import java.util.Scanner;
public class VotingEligibility {
	public static void main(String[] args) {
		Scanner n = new Scanner(System.in);
		System.out.println("Enter your age:");
		int age = n.nextInt();
		if(age>=18) {
			System.out.println("Eligible to vote");
		}
		else {
			System.out.println("Not Eligible to vote79"
					+ "");
		}
		n.close();
	}
}
