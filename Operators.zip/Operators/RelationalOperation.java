package Operators;

public class RelationalOperation {
	public static void main(String[] args) {
        int x = 25;
        int y = 30;
        System.out.println("The value of x is: " + x);
        System.out.println("The value of y is: " + y + "\n");
        System.out.println("Is x equal to y? " + (x == y));
        System.out.println("Is x not equal to y? " + (x != y));
        System.out.println("Is x greater than y? " + (x > y));
        System.out.println("Is x less than y? " + (x < y));
        System.out.println("Is x greater than or equal to y? " + (x >= y));
        System.out.println("Is x less than or equal to y? " + (x <= y));
    }
}

