package Operators;
import java.util.Scanner;
public class IncrementAndDecrement {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
		int a=s.nextInt();
		int b=s.nextInt();
		System.out.println("a++ :"+ a++);
	    System.out.println("++a : "+ ++a);
	    System.out.println("b-- : "+ b--);
	    System.out.println("--b : " + b--);
	    s.close();
}
}
