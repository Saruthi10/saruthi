package Operators;
import java.util.Scanner;
public class TernaryOperator {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int age=sc.nextInt();
	String status=(age>=18)?"Can Vote":"Cannot Vote";
	System.out.println(status);
	sc.close();
}
}
