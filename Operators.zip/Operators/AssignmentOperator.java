package Operators;

public class AssignmentOperator {
public static void main(String[] args) {
	int a=20;
	int b=10;
	int c=30;
	System.out.println("a:"+a);
	System.out.println("b:"+b);
	System.out.println("c:"+c);
	b+=a;
	a-=c;
	c%=b;
	a*=b;
	System.out.println("b+=a : "+b);
	System.out.println("a-=c : "+a);
	System.out.println("a*=b : "+a);
	System.out.println("c%=b : "+c);
}
}
