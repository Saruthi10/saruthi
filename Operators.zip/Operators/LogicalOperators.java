package Operators;

public class LogicalOperators {
public static void main(String[] args) {
	int a=10;
	int b=20;
	int c=30;
	System.out.println("A:"+a);
	System.out.println("B:"+b);
	System.out.println("C:"+c);
	System.out.println("(a<b)&&(b<c):"+((a<b)&&(b<c)));
	System.out.println("(a!=b)||(a==c):"+((a!=b)||(a==c)));
	System.out.println("(a<=b)&&(b>=c):"+((a<=b)&&(b>=c)));
}
}
