package Operators;
import java.util.Scanner;
public class ArithmeticOperation {
public static void main(String[] args) {
	Scanner s= new Scanner(System.in);
	int a=s.nextInt();
	int b=s.nextInt();
	int sum=a+b;
	int sub=a-b;
	int multiple=a*b;
	int division=a/b;
	int modulo=a%b;
	System.out.println("Sum:"+sum);
	System.out.println("Sub:"+sub);
	System.out.println("Multiply:"+multiple);
	System.out.println("Division:"+division);
	System.out.println("Modulo:"+modulo);
	s.close();
}
}
