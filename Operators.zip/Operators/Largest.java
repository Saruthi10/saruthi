package Operators;
import java.util.Scanner;
public class Largest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		String result=((a>b)&&(a>c))?a+" is Greater":((b>a)&&(b>c))?b+" is Greater":c+" is Greater";
		System.out.println(result);
		sc.close();
	}
}
